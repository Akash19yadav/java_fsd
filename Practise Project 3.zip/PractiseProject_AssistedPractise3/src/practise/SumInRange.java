package practise;

public class SumInRange {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int n = arr.length;
        int L = 2; // Starting index of the range
        int R = 5; // Ending index of the range

        int sumInRange = findSumInRange(arr, n, L, R);

        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sumInRange);
    }

    public static int findSumInRange(int[] arr, int n, int L, int R) {
        if (L < 0 || R < 0 || L >= n || R >= n || L > R) {
            throw new IllegalArgumentException("Invalid range or indices.");
        }

        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;
    }
}
