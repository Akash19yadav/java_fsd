package practise;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    public CircularLinkedList() {
        head = null;
    }

    // Method to insert a new element while maintaining sorted order
    public void insertSorted(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            newNode.next = newNode;
            head = newNode;
        } else if (data <= head.data) {
            newNode.next = head;
            Node current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = newNode;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Method to display the circular linked list
    public void display() {
        if (head == null) {
            System.out.println("Circular linked list is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);

        System.out.println();
    }
}

public class InsertSortedCircularLinkedList {
    public static void main(String[] args) {
        CircularLinkedList circularLinkedList = new CircularLinkedList();

        // Insert elements into the sorted circular linked list
        circularLinkedList.insertSorted(3);
        circularLinkedList.insertSorted(5);
        circularLinkedList.insertSorted(2);
        circularLinkedList.insertSorted(6);
        circularLinkedList.insertSorted(4);

        System.out.println("Sorted Circular Linked List:");
        circularLinkedList.display();
    }
}

