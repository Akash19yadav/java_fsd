package practise;

import java.util.PriorityQueue;

public class FourthSmallestNumber {
    public static void main(String[] args) {
        int[] unsortedList = {10, 4, 8, 2, 7, 3, 5, 1, 9, 6};
        
        
        int fourthSmallest = findFourthSmallestElement(unsortedList);
       
        
        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }

    public static int findFourthSmallestElement(int[] arr) {
        if (arr.length < 4) {
            throw new IllegalArgumentException("The array should have at least 4 elements");
        }

        // Create a min-heap (priority queue) to store the smallest elements
        PriorityQueue<Integer> minHeap = new PriorityQueue<>();

        // Insert the first 4 elements into the heap
        for (int i = 0; i < 4; i++) {
            minHeap.offer(arr[i]);
        }

        // Continue iterating through the remaining elements
        // If an element is smaller than the largest element in the heap, replace it
        for (int i = 4; i < arr.length; i++) {
            if (arr[i] < minHeap.peek()) {
                minHeap.poll();
                minHeap.offer(arr[i]);
            }
        }

        // The fourth smallest element will be at the top of the heap
        return minHeap.peek();
    }
}
