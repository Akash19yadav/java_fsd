package practise;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    public LinkedList() {
        head = null;
    }

    // Method to insert a new node at the end of the linked list
    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Method to delete the first occurrence of a key in the linked list
    public void delete(int key) {
        if (head == null) {
            System.out.println("The linked list is empty.");
            return;
        }

        // If the key is found at the head of the list
        if (head.data == key) {
            head = head.next;
            return;
        }

        Node current = head;
        Node prev = null;

        // Traverse the list to find the key or reach the end
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key is found, delete the node
        if (current != null) {
            prev.next = current.next;
        } else {
            System.out.println("Key not found in the linked list.");
        }
    }

    // Method to display the linked list
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}

public class DeleteFirstOccurance {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();

        // Insert elements into the linked list
        linkedList.insert(1);
        linkedList.insert(2);
        linkedList.insert(3);
        linkedList.insert(4);
        linkedList.insert(5);

        System.out.println("Original Linked List:");
        linkedList.display();

        // Delete the first occurrence of key 3
        linkedList.delete(3);

        System.out.println("Linked List after deleting key 3:");
        linkedList.display();
    }
}
