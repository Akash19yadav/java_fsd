package practise;

import java.util.Stack;

public class StackExample {
    public static void main(String[] args) {
        // Create a stack
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack (push)
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);
        stack.push(50);

        System.out.println("Stack after pushing elements: " + stack);

        // Remove elements from the stack (pop)
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);

        System.out.println("Stack after popping an element: " + stack);

        // Get the top element without removing it (peek)
        int topElement = stack.peek();
        System.out.println("Top element (without popping): " + topElement);

        // Check if the stack is empty
        boolean isEmpty = stack.isEmpty();
        System.out.println("Is the stack empty? " + isEmpty);

        // Size of the stack
        int size = stack.size();
        System.out.println("Size of the stack: " + size);
    }
}
