package practise;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {
    public static void main(String[] args) {
        // Create a queue using LinkedList
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue (enqueue)
        queue.add(10);
        queue.add(20);
        queue.add(30);
        queue.offer(40); // Alternative method for enqueue

        System.out.println("Queue after enqueueing elements: " + queue);

        // Remove elements from the queue (dequeue)
        int removedElement = queue.poll(); // Removes and returns the front element
        System.out.println("Removed element: " + removedElement);

        System.out.println("Queue after dequeueing an element: " + queue);

        // Get the front element without removing it (peek)
        int frontElement = queue.peek();
        System.out.println("Front element (without dequeuing): " + frontElement);

        // Check if the queue is empty
        boolean isEmpty = queue.isEmpty();
        System.out.println("Is the queue empty? " + isEmpty);

        // Size of the queue
        int size = queue.size();
        System.out.println("Size of the queue: " + size);
    }
}
