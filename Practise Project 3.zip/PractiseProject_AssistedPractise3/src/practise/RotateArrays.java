package practise;

public class RotateArrays {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        int stepsToRotate = 5;

        System.out.println("Original Array:");
        printArray(array);

        rightRotate(array, stepsToRotate);

        System.out.println("Array after right rotation by " + stepsToRotate + " steps:");
        printArray(array);
    }

    // Method to right rotate an array by a specified number of steps
    public static void rightRotate(int[] arr, int steps) {
        int n = arr.length;
        int[] temp = new int[n];

        // Copy the last 'steps' elements to temp
        for (int i = 0; i < steps; i++) {
            temp[i] = arr[n - steps + i];
        }

        // Shift the remaining elements to the right
        for (int i = 0; i < n - steps; i++) {
            temp[steps + i] = arr[i];
        }

        // Copy elements from temp back to the original array
        for (int i = 0; i < n; i++) {
            arr[i] = temp[i];
        }
    }

    // Utility method to print an array
    public static void printArray(int[] arr) {
        for (int num : arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
