package practiseproject_2;

//Step 1: Define a class
class Animal {
 // Step 2: Define instance variables (attributes)
 private String name;
 private int age;

 // Step 3: Define a constructor to initialize the object
 public Animal(String name, int age) {
     this.name = name;
     this.age = age;
 }

 // Step 4: Define methods (behaviors)
 public void speak() {
     System.out.println(name + " is an animal.");
 }

 // Encapsulation: Use getters and setters for private variables
 public String getName() {
     return name;
 }

 public int getAge() {
     return age;
 }

 public void setName(String name) {
     this.name = name;
 }

 public void setAge(int age) {
     this.age = age;
 }
}

//Step 5: Inheritance: Create a subclass
class Dog extends Animal {
 // Additional attributes and methods specific to Dog class
 public Dog(String name, int age) {
     super(name, age); // Call the superclass constructor
 }

 @Override
 public void speak() {
     System.out.println(getName() + " is a dog and says woof!");
 }
}

//Step 6: Polymorphism: Create a method that accepts objects of different types
class AnimalShelter {
 public void introduceAnimal(Animal animal) {
     System.out.println("Welcome, " + animal.getName() + "!");
     animal.speak();
 }
}

public class OopDemo {
 public static void main(String[] args) {
     // Step 7: Create objects and demonstrate OOP principles
     AnimalShelter shelter = new AnimalShelter();

     Animal genericAnimal = new Animal("Generic Animal", 5);
     Dog myDog = new Dog("Buddy", 3);

     // Abstraction: We don't need to know the specific implementation of 'speak' here
     shelter.introduceAnimal(genericAnimal);
     shelter.introduceAnimal(myDog);

     // Accessing attributes using encapsulation
     System.out.println(myDog.getName() + " is " + myDog.getAge() + " years old.");

     // Encapsulation: Modify attributes using setters
     myDog.setAge(4);
     myDog.setName("Max");

     System.out.println(myDog.getName() + " is now " + myDog.getAge() + " years old.");
 }
}
