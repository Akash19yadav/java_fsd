package practiseproject_2;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
public class File_Create_Read_Delete {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		/*File f=new File("C:\\Users\\Hunter\\OneDrive\\Desktop\\file");
		if(f.createNewFile()) {
			System.out.println("File successfully created..!");
		}
		else {
			System.out.println("File Already Exist...!");
		}*/
   /*  FileReader r = new FileReader("C:\\\\Users\\\\Hunter\\\\OneDrive\\\\Desktop\\\\file");
         int i;
     while((i=r.read())!=-1) {
    	 System.out.print((char)i);
     }*/
     File file = new File("C:\\Users\\Aashish\\OneDrive\\Desktop\\file");

 if (file.delete()) {
     System.out.println("File deleted successfully");
 }
 else {
     System.out.println("Failed to delete the file");
 }
	}

}