package practiseproject_2;

interface father{
	public default void display() {
		System.out.println("i,m your father");
	}
}
interface grandfather{
	public default void display() {
		System.out.println("I,m your grandfather");
	}
}
 class Child implements father,grandfather{
	public  void display() {
		father.super.display();
		grandfather.super.display();
		
	}
}
public class Daimond_Problem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child x=new Child();
		x.display();

	}

}