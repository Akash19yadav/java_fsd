package practiseproject_2;

public class SleepAndwait {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		 final Object obj = new Object();   
		  
		    
	        Thread.sleep(2000);   
	          
	      
	        System.out.println( Thread.currentThread().getName() +   
	        " Thread is woken after two second");   
	          
	        
	        synchronized (obj)    
	        {   
	         
	            obj.wait(2000);   
	  
	            System.out.println(obj + " Object is in waiting state and woken after 2 seconds");   
	        }   

	}

}
