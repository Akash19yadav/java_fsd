package practiseproject_2;

class Table{
	synchronized void PrintTable(int n){
		for(int i=1;i<=5;i++) {
			System.out.println(n*i);
		}
	}
}
class MyThread extends Thread{
	Table t;
	MyThread(Table t){
		this.t=t;
	}
	public void run() {
		t.PrintTable(10);
	}
}
class MyThread1 extends Thread{
	Table t;
	MyThread1(Table t){
		this.t=t;
	}
	public void run() {
		t.PrintTable(14);
	}
}

public class Synchro {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Table T=new Table();
	       MyThread m=new MyThread(T);
	       MyThread1 m1=new MyThread1(T);
	       m.start();
	       m1.start();
	}

}