package practiseproject_2;

class CustomException extends Exception {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CustomException(String message) {
        super(message);
    }
}

public class Throw_throws_customExc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 try {
	            int result = divide(5, 2);
	            System.out.println("Result: " + result);
	        } catch (CustomException ce) {
	            System.err.println("Custom Exception caught: " + ce.getMessage());
	        } catch (ArithmeticException ae) {
	            System.err.println("Arithmetic Exception caught: " + ae.getMessage());
	        } finally {
	            System.out.println("Finally block executed.");
	        }
	    }

	    public static int divide(int num1, int num2) throws CustomException {
	        try {
	            if (num2 == 0) {
	                throw new CustomException("Division by zero is not allowed.");
	            }
	            return num1 / num2;
	        } catch (ArithmeticException ae) {
	            throw ae;
	        }

	}

}