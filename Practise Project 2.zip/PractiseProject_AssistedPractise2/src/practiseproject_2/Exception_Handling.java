package practiseproject_2;

public class Exception_Handling {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//printstakTrace
		 int a=20;
	      int b=0;
	        try{
	          System.out.println(a/b);
	        }
	      catch(ArithmeticException e){
	        e.printStackTrace();
	        System.out.println("error is ArithmeticException");
	      }
      //exception information using toString() method
	        int a1=5;
	        int b1=0;
	          try{
	            System.out.println(a1/b1);
	          }
	        catch(ArithmeticException e){
	          System.out.println(e.toString());
	        }
	}

}