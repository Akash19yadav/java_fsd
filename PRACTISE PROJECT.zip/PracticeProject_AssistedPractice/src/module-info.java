/**
 * 
 */
/**
 * @author lappy
 *
 */
module PracticeProject_AssistedPractice {
}