package practise;

public class Calling_methods {
    // Instance method
    public void instanceMethod() {
        System.out.println("Inside instanceMethod()");
    }

    // Static method
    public static void staticMethod() {
        System.out.println("Inside staticMethod()");
    }

    // Parameterized method
    public void parameterizedMethod(int num) {
        System.out.println("Inside parameterizedMethod(). Received: " + num);
    }

    // Method with return value
    public int add(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        // Creating an object of the class to call instance methods
    	Calling_methods obj = new Calling_methods();

        // Calling instance method using object
        obj.instanceMethod();

        // Calling static method using class name
        Calling_methods.staticMethod();

        // Calling parameterized method
        obj.parameterizedMethod(42);

        // Calling method with return value
        int result = obj.add(10, 20);
        System.out.println("Result of add(10, 20): " + result);
    }
}
