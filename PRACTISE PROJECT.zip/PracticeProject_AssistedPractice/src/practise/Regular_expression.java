package practise;
import java.util.regex.*;

public class Regular_expression {
	

	
	    public static void main(String[] args) {
	        // Input string
	        String text = "The king is back.";

	        // Pattern for matching words
	        String wordPattern = "hunter";

	        // Pattern for matching email addresses
	        String emailPattern = "xyz@gmail.com";

	        // Pattern for matching phone numbers in the format (123) 456-7890
	        String phonePattern = "11111111";

	        // Pattern for matching dates in the format YYYY-MM-DD
	        String datePattern = "12\12\2222";

	        // Pattern for matching URLs starting with http or https
	        String urlPattern = "https?://[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}(/\\S*)?";

	        // Compile the regular expressions
	        Pattern wordRegex = Pattern.compile(wordPattern);
	        Pattern emailRegex = Pattern.compile(emailPattern);
	        Pattern phoneRegex = Pattern.compile(phonePattern);
	        Pattern dateRegex = Pattern.compile(datePattern);
	        Pattern urlRegex = Pattern.compile(urlPattern);

	        // Match words in the text
	        Matcher wordMatcher = wordRegex.matcher(text);
	        System.out.println("Words in the text:");
	        while (wordMatcher.find()) {
	            System.out.println(wordMatcher.group());
	        }

	        // Match email addresses in the text
	        Matcher emailMatcher = emailRegex.matcher(text);
	        System.out.println("\nEmail addresses in the text:");
	        while (emailMatcher.find()) {
	            System.out.println(emailMatcher.group());
	        }

	        // Match phone numbers in the text
	        Matcher phoneMatcher = phoneRegex.matcher(text);
	        System.out.println("\nPhone numbers in the text:");
	        while (phoneMatcher.find()) {
	            System.out.println(phoneMatcher.group());
	        }

	        // Match dates in the text
	        Matcher dateMatcher = dateRegex.matcher(text);
	        System.out.println("\nDates in the text:");
	        while (dateMatcher.find()) {
	            System.out.println(dateMatcher.group());
	        }

	        // Match URLs in the text
	        Matcher urlMatcher = urlRegex.matcher(text);
	        System.out.println("\nURLs in the text:");
	        while (urlMatcher.find()) {
	            System.out.println(urlMatcher.group());
	        }
	    }
	


}
