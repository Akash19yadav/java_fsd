package practise;

public class String_conversion {
	
	    public static void main(String[] args) {
	        // Create a string
	        String str = "Hello, World!";

	        // Convert to StringBuffer
	        StringBuffer stringBuffer = new StringBuffer(str);

	        // Convert to StringBuilder
	        StringBuilder stringBuilder = new StringBuilder(str);

	        // Display the original string
	        System.out.println("Original String: " + str);

	        // Display the StringBuffer version
	        System.out.println("StringBuffer Version: " + stringBuffer.toString());

	        // Display the StringBuilder version
	        System.out.println("StringBuilder Version: " + stringBuilder.toString());
	    }
	
}
