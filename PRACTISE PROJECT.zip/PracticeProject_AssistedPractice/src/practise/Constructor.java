package practise;

public class Constructor {
    private String name;
    private int age;

    // No-argument constructor (default constructor)
    public Constructor() {
        System.out.println("Inside the no-argument constructor.");
        name = "Unknown";
        age = 0;
    }

   
    public Constructor(String n, int a) {
        System.out.println("Inside the parameterized constructor.");
        name = n;
        age = a;
    }

    // Constructor chaining: Calling one constructor from another
    public Constructor(String n) {
        this(n, 0); // Calls the parameterized constructor with default age
    }

    // Method to display object details
    public void display() {
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
    }

    public static void main(String[] args) {
        // Creating objects using different constructors
        Constructor obj1 = new Constructor(); // No-argument constructor
        Constructor obj2 = new Constructor("Hunter", 25); // Parameterized constructor
        Constructor obj3 = new Constructor("Sam"); // Constructor chaining

        // Displaying object details
        System.out.println("\nObject 1:");
        obj1.display();

        System.out.println("\nObject 2:");
        obj2.display();

        System.out.println("\nObject 3:");
        obj3.display();
    }
}
