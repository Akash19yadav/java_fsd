package practise;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashSet;
import java.util.HashMap;
import java.util.Iterator;

public class Collection {

	public static void main(String[] args) {
        // ArrayList example
        ArrayList<String> arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Banana");
        arrayList.add("Orange");
        
        System.out.println("ArrayList:");
        for (String fruit : arrayList) {
            System.out.println(fruit);
        }

        // LinkedList example
        LinkedList<Integer> linkedList = new LinkedList<>();
        linkedList.add(10);
        linkedList.add(20);
        linkedList.add(30);
        
        System.out.println("\nLinkedList:");
        for (Integer number : linkedList) {
            System.out.println(number);
        }

        // HashSet example (Set does not allow duplicate elements)
        HashSet<String> hashSet = new HashSet<>();
        hashSet.add("Red");
        hashSet.add("Green");
        hashSet.add("Blue");
        hashSet.add("Red"); // Duplicate, won't be added
        
        System.out.println("\nHashSet:");
        for (String color : hashSet) {
            System.out.println(color);
        }

        // HashMap example (key-value pairs)
        HashMap<String, Integer> hashMap = new HashMap<>();
        hashMap.put("Hunter", 30);
        hashMap.put("Sahil", 25);
        hashMap.put("Sam", 35);
        
        System.out.println("\nHashMap:");
        // Iterating over keys
        for (String name : hashMap.keySet()) {
            System.out.println(name + ": " + hashMap.get(name));
        }

        // Using Iterator to iterate over values
        System.out.println("\nHashMap values (using Iterator):");
        Iterator<Integer> iterator = hashMap.values().iterator();
        while (iterator.hasNext()) {
            System.out.println(iterator.next());
        }
    }

		

	}


