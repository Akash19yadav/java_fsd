package practise;

public class Array {
	    public static void main(String[] args) {
	    	
	        // Declare and initialize an integer array
	        int[] numbers = { 1, 2, 3, 4, 5 };

	        // Access elements of the array and print them
	        System.out.println("Elements of the array:");
	        for (int i = 0; i < numbers.length; i++) {
	            System.out.println("Element at index " + i + ": " + numbers[i]);
	        }

	        // Calculate and print the sum of array elements
	        int sum = 0;
	        for (int number : numbers) {
	            sum += number;
	        }
	        System.out.println("Sum of array elements: " + sum);

	        // Declare and initialize a string array
	        String[] names = { "Alice", "Bob", "Charlie", "David" };

	        // Access and print elements of the string array
	        System.out.println("\nNames in the array:");
	        for (String name : names) {
	            System.out.println(name);
	        }

	        // 2D array (matrix) example
	        int[][] matrix = {
	            { 1, 2, 3 },
	            { 4, 5, 6 },
	            { 7, 8, 9 }
	        };

	        System.out.println("\n2D Array (Matrix):");
	        for (int[] row : matrix) {
	            for (int num : row) {
	                System.out.print(num + " ");
	            }
	            System.out.println(); // Move to the next row
	        }
	    }
	

}
